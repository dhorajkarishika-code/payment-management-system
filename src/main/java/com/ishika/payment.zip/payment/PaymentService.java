package com.ishika.payment;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ishika.payment.dto.PaymentRequestDTO;
import com.ishika.payment.dto.PaymentResponseDTO;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository repository;

    // Convert Entity -> DTO
    private PaymentResponseDTO convertToDTO(Payment payment) {

        return new PaymentResponseDTO(
                payment.getId(),
                payment.getAmount(),
                payment.getStatus(),
                payment.getCreatedAt(),
                payment.getUpdatedAt());
    }

    // CREATE
    public PaymentResponseDTO save(PaymentRequestDTO dto) {

        Payment payment = new Payment();

        payment.setAmount(dto.getAmount());
        payment.setStatus(dto.getStatus());

        Payment saved = repository.save(payment);

        return convertToDTO(saved);
    }

    // GET ALL
    public List<PaymentResponseDTO> getAll() {

        return repository.findAll()
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    // GET BY ID
    public PaymentResponseDTO getById(int id) {

        Payment payment = repository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Payment not found with ID: " + id));

        return convertToDTO(payment);
    }

    // UPDATE
    public PaymentResponseDTO update(int id, PaymentRequestDTO dto) {

        Payment payment = repository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Payment not found with ID: " + id));

        payment.setAmount(dto.getAmount());
        payment.setStatus(dto.getStatus());

        Payment updated = repository.save(payment);

        return convertToDTO(updated);
    }

    // DELETE
    public void delete(int id) {

        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException(
                    "Payment not found with ID: " + id);
        }

        repository.deleteById(id);
    }

}